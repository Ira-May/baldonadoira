const express = require('express');
const router = express.Router();
const dev = require('../controller/devController');

router.get('/', dev.app);
router.get('/about', dev.about);
router.get('/contact', dev.contact);
router.get('/email', dev.email);
router.get('/login', dev.login);
module.exports = router;

